#!/bin/bash
# $Id: EMS_install.sh 2016-11-14
# Installer to write EMS dev files to Linux.
#
# Copyright (C) 2016 IDERA
#
# Servers:
#   EMSDevServerCommand
#   mod_emsserver
#
# Tools:
#   EMSDevConsoleCommand
#   mod_emsconsole
#
# Packages:
#   packages needed by server or tools (RTL)
#
# ObjRepos files needed by EMSDevConsole:
#   objrepos\webresources
#   objrepos\ems\EMSMSERVER.IB
#   objrepos\ems\EMSMSERVER.SQL
#   objrepos\ems\emsserver.ib
#   objrepos\ems\emsserver.sql
#   objrepos\ems\emsserver.ini
#

# sub program for prompt
promptyn () {
  while true; do
    echo -n "$1 [y/n]?"
    read yn
    case $yn in
      [Yy]* ) return 0;;
      [Nn]* ) return 1;;
      * ) echo "Please press Y (for yes) or N (for no)";;
    esac
  done
}

pushd .

echo Start installing the EMS server > /var/emsserver_install.log

# check if EMS server is already exist
if [ -d /usr/lib/ems ]; then
  echo "EMS server seems to be already installed on your machine (/usr/lib/ems folder is exist)"
  if ! promptyn "Do you want to replace it ?"; then
    exit
  fi
fi

# create needs directories
mkdir -p /usr/lib/ems >> /var/emsserver_install.log
mkdir -p /etc/ems >> /var/emsserver_install.log
mkdir -p /etc/ems/objrepos >> /var/emsserver_install.log

echo Unpack EMS files...
echo [ Unpack EMS files... ] >> /var/emsserver_install.log
if [ -d EMS_temp ]; then
  rm -r EMS_temp
fi

mkdir EMS_temp
cd EMS_temp

tar xf ../LinuxEMSServer.tar >> /var/emsserver_install.log
echo unpack done.
echo [ unpack done. ] >> /var/emsserver_install.log

echo Copy files:
echo [ Copy files: ] >> /var/emsserver_install.log

echo -servers and tools..
echo [ -servers and tools.. ] >> /var/emsserver_install.log
cp -v server/EMSDevConsoleCommand /usr/lib/ems >> /var/emsserver_install.log
cp -v server/EMSDevServerCommand /usr/lib/ems >> /var/emsserver_install.log
cp -v server/EMSMultiTenantConsole /usr/lib/ems >> /var/emsserver_install.log
cp -v server/libmod_emsserver.so /usr/lib/ems >> /var/emsserver_install.log
cp -v server/libmod_emsconsole.so /usr/lib/ems >> /var/emsserver_install.log

echo -ib, sql, ini..
echo [ -ib, sql, ini.. ] >> /var/emsserver_install.log
cp -rv objrepos /etc/ems >> /var/emsserver_install.log

echo -runtime packages..
echo [ -runtime packages.. ] >> /var/emsserver_install.log
cp -rv rtl/* /usr/lib/ems >> /var/emsserver_install.log

echo copy done.
echo [ copy done. ] >> /var/emsserver_install.log

echo Assign rights...
echo [ Assign rights... ] >> /var/emsserver_install.log
chown -R :adm /usr/lib/ems/* >> /var/emsserver_install.log
chown -R :adm /etc/ems/objrepos/* >> /var/emsserver_install.log

chmod =x+r /usr/lib/ems/EMSDevConsoleCommand >> /var/emsserver_install.log
chmod =x+r /usr/lib/ems/EMSDevServerCommand >> /var/emsserver_install.log
echo assign rights done.
echo [ assign rights done. ] >> /var/emsserver_install.log

popd
rm -r EMS_temp

# set environment variables
if [ -z $(grep -r -e 'EMS_CONF' /etc/environment) ]; then
  echo 'EMS_CONF=/etc/ems' >> /etc/environment
fi

if [ -z $(grep -r -e 'EMS_OBJREPOS' /etc/environment) ]; then
  echo 'EMS_OBJREPOS=/etc/ems/objrepos' >> /etc/environment
fi

if [ -z $(grep -r -e 'EMS_HOME' /etc/environment) ]; then
  echo 'EMS_HOME=/usr/lib/ems' >> /etc/environment
fi

echo EMS server has been installed. You can find details at /var/emsserver_install.log
echo [ EMS server has been installed. ] >> /var/emsserver_install.log

